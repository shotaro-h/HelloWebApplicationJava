package dto;

public abstract class BaseDTO{
}
